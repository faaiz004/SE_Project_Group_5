import mongoose from 'mongoose';

const postSchema = new mongoose.Schema({
  imageUrl: {
    type: String,
    required: true
  },
  caption: {
    type: String,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  likes: {
    type: Number,
    default: 0
  },
  clothes: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Clothes'
    }
  ]
});

const Post = mongoose.model('Post', postSchema);

export default Post;
